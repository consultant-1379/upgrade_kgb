==================
Django Integration
==================

.. automodule:: fabric.contrib.django
    :members:
